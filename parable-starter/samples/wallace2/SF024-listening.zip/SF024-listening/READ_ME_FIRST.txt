SF-024 — Wallace II listening package

Start with05_pre_cab_clean_matched.wav. Compare06_CONTROL_clean_disabled,
then07_more_clean_less_muff. Compare05 against08_post_cab_studio;09 adds
restrained ducking;10 is deliberately expansive.01–03 isolate cabinet coloration;
04 is the original serial control. All ten *_matched.wav files are−23LUFS.

Default: clean .50, separate Muff .75. Clean bypasses the four effects, then
passes the common cabinet.06 is a clean-disabled CONTROL, never the default.

The three included *_stem_*_listen.wav files isolate the clean contribution,
before/after cabinet for05 and after cabinet for08. They use the fullmix listening
gain, with no independent solo boost. *_common_gain.wav files use one identical
gain across05/06/07 to expose the actual level change when clean is muted.

16 mono48k PCM16 WAVs:10 matched fullmixes,3 clean solos,3 common-gain controls.
Each is29seconds (20second performance plus9second effect tail). Additional
fuzz/ambience diagnostics, unnormalized raw files and original recordings remain
in the repository; they are not duplicated in this compact listening ZIP.

Preserve GUITAR_NOTICE.md and IR_NOTICE.md when redistributing these recordings.
No Daisy runtime or human musical-quality approval is claimed.
Source PR: https://github.com/amstarhd-dev/parable/pull/79
Native render source:337718ab31a72d6b2b718a20f4f376a5d5594c7a
